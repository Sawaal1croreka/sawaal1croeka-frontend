import Passive from '../components/Passive.js'

export default function Home() {
  return (
      <Passive />
  )
}
