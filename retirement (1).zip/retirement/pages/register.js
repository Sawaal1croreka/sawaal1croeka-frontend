import Register from '../components/auth/Register.js'

export default function Home() {
  return (
      <Register />
  )
}
