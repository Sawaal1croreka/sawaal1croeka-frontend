import Retire from "../components/Retire.js";

export default function Home() {
  return (
    <div>
      <Retire />
    </div>
  );
}
